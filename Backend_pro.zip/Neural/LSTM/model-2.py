# -*- coding: utf-8 -*-
"""
Created on Sun Apr 14 16:07:24 2019

@author: Elsayed
"""

import pandas
import numpy as np
import datetime as dt
import matplotlib.pyplot as plt
from keras.callbacks import EarlyStopping
from sklearn.preprocessing import MinMaxScaler
from keras.models import Sequential, load_model
from keras.layers import Dense, Dropout, LSTM

#################### Start PreProcessing ####################
def preProcessing(companiesName, Input, Output, normalize, spliteRation, steps, predictNumber):
    print("[Data] Preprocessing Data Started...")
    features, inputIndex, outputIndex = Features(Input, Output)
    shape = len(features)
    xData = []
    yData = []
    for name in companiesName:
        data = []
        data = loadingData(name)
        cleanedData = getFeatures(data, features)
        dataScaled, scaler = Normalize(cleanedData, normalize)
        inputData, outputData = creatInputOutput(dataScaled, inputIndex, outputIndex)
        x, y = creatTimeSteps(inputData, outputData, steps, predictNumber)
        xData += list(x)
        yData += list(y)
     
    x_train, y_train, x_test, y_test, x_validation, y_validation = dataSplit(xData, yData, spliteRation)
    x_train, y_train, x_test, y_test, x_validation, y_validation = np.array(x_train), np.array(y_train), np.array(x_test), np.array(y_test), np.array(x_validation), np.array(y_validation)
    print("[Data] Preprocessing Data Compiled.")
    return x_train, y_train, x_test, y_test, x_validation, y_validation, scaler, shape

def loadingData(name):
    dataFram = pandas.read_csv('Dataset/' + name + '.csv')
    return dataFram

def Features(inputData, outputData):
    features = inputData
    inputIndex = []
    outputIndex = []
    for x in outputData:
        if x not in features:
            features += [x]
    for index in range(len(features)):
        if features[index] in inputData:
            inputIndex += [index]
        if features[index] in outputData:
            outputIndex += [index]
    return features, inputIndex, outputIndex

def getFeatures(data, features):
    cleanedData = data.get(features).values
    return cleanedData

def Normalize(data, mode = 1):
    if mode == 0:
        return data, None
    elif mode == 1:
        scaler = MinMaxScaler(feature_range = (0, 1))
        dataScaled = scaler.fit_transform(data)
        return dataScaled, scaler
    elif mode == 2:
        scaler = MinMaxScaler(feature_range = (-1, 1))
        dataScaled = scaler.fit_transform(data)
        return dataScaled, scaler

def invertNormalize(scaler, data, shape):
    if data.shape[0] % 2 != 0:
        data = data[0:-1]
    data = data.reshape((-1, shape))
    invertedData = scaler.inverse_transform(data)
    invertedData = invertedData.reshape(-1, 1)
    return invertedData

def creatInputOutput(data, Input, Output):
    inputData = np.take(data, Input, axis = 1)
    outputData = np.take(data, Output, axis = 1)
    return inputData, outputData

def creatTimeSteps(inputData, outputData, steps = 1, predictNumber = 1):
    x = np.array([inputData[i : i + steps] for i in range(len(inputData) - steps - predictNumber)])
    y = np.array([outputData[i + steps : i + steps + predictNumber] for i in range(len(outputData) - steps - predictNumber)])
    y = y.reshape(-1,1)
    return x, y

def dataSplit(x, y, spliteRation):
    iSplit = int(len(x) * spliteRation)
    splitValidation = int(len(x[iSplit: ]) / 2) + iSplit
    xTrain, yTrain = x[:iSplit], y[:iSplit]
    xTest, yTest = x[iSplit : splitValidation], y[iSplit : splitValidation]
    xValidation, yValidation = x[splitValidation: ], y[splitValidation: ]
    return xTrain, yTrain, xTest, yTest, xValidation, yValidation

#################### End PreProcessing ####################


#################### Start Creat Model ####################

def creatModel(x_train, y_train, x_test, y_test, x_validation, y_validation, n_batch, timeSteps, feature_num, epoch_no):
    print('[Model] Build Model Started...')
    model = Sequential()
    model.add(LSTM(timeSteps, input_shape = (timeSteps, feature_num), return_sequences = True))
    model.add(Dropout(0.2))
    model.add(LSTM(timeSteps, return_sequences = True))
    model.add(Dropout(0.2))
    model.add(LSTM(timeSteps, return_sequences = False))
    model.add(Dense(1, activation = 'linear'))
    model.compile(loss='mse', optimizer = 'adam')
    model.summary()
    print('[Model] Model Compiled.')
    
    model.fit(x_train, y_train, epochs = epoch_no, batch_size = 32, callbacks = [EarlyStopping(patience=2)], validation_data=(x_validation, y_validation))
    score = model.evaluate(x_test, y_test, batch_size = 32)
    print("Test score:", score)
    
    save_fname = dt.datetime.now().strftime('%d%m%Y-%H%M%S') + '-LSTM.h5'
    model.save('models/' + save_fname)
    
    m = load_model('models/' + save_fname)
    
    trainPredict = m.predict(x_train[0])
    testPredict = m.predict(x_test[0])
    
    return model, trainPredict, testPredict

def trainModel(model, epoch_no, x_train, y_train):
    print('[Model] Training Started...')
    model.fit(x_train, y_train, epochs = epoch_no, batch_size = 32, callbacks = [EarlyStopping(patience=2)], validation_data=(x_validation, y_validation))
    save_fname = dt.datetime.now().strftime('%d%m%Y-%H%M%S') + '-LSTM.h5'
    model.save('models/' + save_fname)
    print('[Model] Training Completed.')
    return model

def testModel(model, x_test, y_test):
    print('[Model] Test Model Started...')
    score = model.evaluate(x_test, y_test, batch_size = 32)
    print("Test score:", score)
    print('[Model] Test Model Completed.')
    trainPredict = model.predict(x_train)
    testPredict = model.predict(x_test)
    return trainPredict, testPredict

def predictModel(model, data):
    y_pred = model.predict(data)
    return y_pred

#################### End Creat Model ####################

def plot(real, predict):
    fig = plt.figure()
    ax = plt.subplot(111)
    ax.plot(real, color = 'blue', label = 'Real Stock Price')
    ax.plot(predict, color = 'green', label = 'Predicted Stock Price')
    plt.title('Stock Price Prediction')
    plt.xlabel('Time')
    plt.ylabel('Stock Price')
    plt.legend()
    fig.savefig('images/' + dt.datetime.now().strftime('%d%m%Y-%H%M%S') + 'FB-LSTM.png')

#################### Start Main ####################
companiesName = ['FB-7']
Input =  ['Close']
Output = ['Close']
normalize = 1
spliteRation = 0.8
timeSteps = 60
predictNumber = 1
n_batch = timeSteps
feature_num = 1
epoch_no = 100

x_train, y_train, x_test, y_test, x_validation, y_validation, scaler, shape = preProcessing(companiesName,
                                                                                            Input, Output,
                                                                                            normalize, spliteRation,
                                                                                            timeSteps, predictNumber)

model,trainPredict,testPredict = creatModel(x_train, y_train, x_test, y_test,x_validation, y_validation, n_batch, timeSteps, feature_num, epoch_no)

realTest = invertNormalize(scaler, y_test, shape)
predTest = invertNormalize(scaler, testPredict, shape)

realTrain = invertNormalize(scaler, y_train, shape)
predTrain = invertNormalize(scaler, trainPredict, shape)

rmsTrain = np.sqrt(np.mean(np.square((predTrain - realTrain))))
rmsTest = np.sqrt(np.mean(np.square((predTest - realTest))))

plot(realTest, predTest)

print('Train => ', rmsTrain)
print('Test => ', rmsTest)

#################### End Main ####################