# -*- coding: utf-8 -*-
"""
Created on Sat Apr 27 19:23:07 2019

@author: Elsay
"""

import pandas
import numpy as np
import matplotlib.pyplot as plt
from keras.models import load_model
from sklearn.preprocessing import MinMaxScaler

def getData(dayNumber, path, features, timeStep):
    data = pandas.read_csv(path)
    data = data.get(features).values
    fristIndex = len(data) - (dayNumber + timeStep)
    data = data[fristIndex : ].reshape(-1,1)
    scaler = MinMaxScaler(feature_range = (0, 1))
    scaler = scaler.fit(data)
    data = scaledData(data, scaler)
    xInput = np.array([ data[i : i + timeStep] for i in range(1, len(data) - timeStep + 1)])
    return xInput, scaler

def predictModel(model, data):
    y_pred = model.predict(data)
    return y_pred

def loadModel(path):
    model = load_model(path)
    return model

def scaledData(data, scaler, normalize = 'normalize'):
    if normalize == 'normalize':
        scaledData = scaler.fit_transform(data)
        return scaledData
    elif normalize == 'invert':
        scaledData = scaler.inverse_transform(data)
        return scaledData

x, scaler = getData(100, 'Dataset/FB-7.csv', 'Close', 60)

model = loadModel('models/27042019-135806-LSTM.h5')

pre = predictModel(model, x)
pre = scaledData(pre, scaler, 'invert')
ax = plt.subplot(111)
ax.plot(pre, color = 'green', label = 'Real Stock Price')
ax.plot(pre, color = 'green', label = 'Real Stock Price')